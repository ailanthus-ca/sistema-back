<?php
/**
 * Created by PhpStorm.
 * User: Ailanthus
 * Date: 18-01-2018
 * Time: 01:04 PM
 */

 include '../templates/template.php';
 include '../../config/conexion.php';

?>

<div class="col-xs-12" style="margin: auto; left: 41%; margin-top: 20%">
        <img src="public/imagenes/logo_acerca.jpg"  alt="Logo"  >
</div>
        <div align="center">
            <p>Desarrollado por Ailanthus Sistems C.A</p>
            <p></p>
            <p align="center">Versión: 2.0</p>
            <p></p>
        </div>
<?php
    include("../templates/template_footer.php");
?>
