<?php
$user = "desarrollador";
$pass = "2amu3azap";
$server = "192.168.1.31";
$db = "Emergencia";
$con = mysqli_connect($server, $user, $pass,$db);
$con->set_charset('utf8');
return $con;
?>