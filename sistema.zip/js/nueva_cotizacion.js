var itens = [];
$(document).ready(function () {
    load(1);
    $('[data-toggle="tooltip"]').tooltip();
    $('[data-toggle="modal"]').tooltip();
});
function load(page) {
    //resetear botones
    document.getElementById("guardar_cliente").reset();
    document.getElementById("guardar_producto").reset();
    document.getElementById("codigo").focus();
}

//Buscar clientes por autocompletado cedula
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
$(function () {
    $("#codigo_cliente").autocomplete({
        source: 'ajax/autocomplete/clientes_cod.php',
        minLength: 2,
        select: function (event, ui) {
            event.preventDefault();
            $('#codigo_cliente').val(ui.item.id_cliente);
            $('#nombre_cliente').val(ui.item.nombre_cliente);
            $('#tel1').val(ui.item.telefono_cliente);
            $('#mail').val(ui.item.email_cliente);
            $('#direccion_cliente').val(ui.item.direccion_cliente);
        }
    }
    )
});
$("#codigo_cliente").on("keydown", function (event) {
    if (event.keyCode == $.ui.keyCode.LEFT || event.keyCode == $.ui.keyCode.RIGHT || event.keyCode == $.ui.keyCode.UP || event.keyCode == $.ui.keyCode.DOWN || event.keyCode == $.ui.keyCode.DELETE || event.keyCode == $.ui.keyCode.BACKSPACE)
    {
        $("#id_cliente").val("");
        $("#nombre_cliente").val("");
        $("#tel1").val("");
        $("#mail").val("");
        $('#direccion_cliente').val('');
    }
    if (event.keyCode == $.ui.keyCode.DELETE) {
        $("#nombre_cliente").val("");
        $("#id_cliente").val("");
        $("#tel1").val("");
        $("#mail").val("");
        $('#direccion_cliente').val('');
    }
});
//Buscar clientes por autocompletado nombre
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
$(function () {
    $("#nombre_cliente").autocomplete({
        source: "ajax/autocomplete/clientes_nom.php",
        minLength: 2,
        select: function (event, ui) {
            event.preventDefault();
            $('#codigo_cliente').val(ui.item.id_cliente);
            $('#nombre_cliente').val(ui.item.nombre_cliente);
            $('#tel1').val(ui.item.telefono_cliente);
            $('#mail').val(ui.item.email_cliente);
            $('#direccion_cliente').val(ui.item.direccion_cliente);
        }
    });
});
$("#nombre_cliente").on("keydown", function (event) {
    if (event.keyCode == $.ui.keyCode.LEFT || event.keyCode == $.ui.keyCode.RIGHT || event.keyCode == $.ui.keyCode.UP || event.keyCode == $.ui.keyCode.DOWN || event.keyCode == $.ui.keyCode.DELETE || event.keyCode == $.ui.keyCode.BACKSPACE)
    {
        $("#id_cliente").val("");
        $("#codigo_cliente").val("");
        $("#tel1").val("");
        $("#mail").val("");
        $('#direccion_cliente').val('');
    }
    if (event.keyCode == $.ui.keyCode.DELETE) {
        $("#nombre_cliente").val("");
        $("#id_cliente").val("");
        $("#tel1").val("");
        $("#mail").val("");
        $('#direccion_cliente').val('');
    }
});
function editarFactura(id) {
    $("#carga").fadeIn('slow');
    $.ajax({
        url: "ajax/cotizacion/editar_cotizacion.php?id=" + id,
        beforeSend: function (objeto) {
            $('#carga').html('<img src="./public/imagenes/ajax-loader.gif"> Cargando...');
        },
        success: function (data) {
            $(".edit").html(data).show('slow');
            $('#carga').html('');
        }
    })
}

function comentario(id) {
    $(document).ready(function () {
        $("#cargagif").load("ajax/cotizacion/comentario_cotizacion.php?id=" + id, function () {
            $("#resultado_comentario").html('');
            $("#cargagif").show("slow");
            $("#coment").hide("slow");
        });
    });
}

function agregarComentario(id)
{

    var comentario = document.getElementById('comentario' + id).value;
    $.ajax({
        type: "POST",
        url: "./ajax/cotizacion/agregar_comentario.php",
        data: "id=" + id + "&comentario=" + comentario,
        beforeSend: function (objeto) {
            $("#resultado_comentario").html("Mensaje: Cargando...");
        },
        success: function (datos) {
            $("#resultado_comentario").html(datos);
        }
    });
}

function editarProducto(id)
{

    var precio_venta = document.getElementById('precio_venta' + id).value;
    var cantidad = document.getElementById('cantidad' + id).value;
    var costo = document.getElementById('costo').value;
    //Inicia validacion
    if (parseFloat(precio_venta) < parseFloat(costo))
    {
        alert('El precio no puede ser menor que el costo');
        document.getElementById('precio_venta' + id).focus();
        return false;
    }
    if (isNaN(cantidad))
    {
        alert('La cantidad debe ser un valor numerico entero');
        document.getElementById('cantidad' + id).focus();
        return false;
    }
    if (cantidad == "") {
        alert('Ingrese una cantidad');
        document.getElementById('cantidad' + id).focus();
        return false;
    }
    if (isNaN(precio_venta))
    {
        alert('El precio debe ser un valor numerico');
        document.getElementById('precio_venta' + id).focus();
        return false;
    }
//Fin validacion


    $.ajax({
        type: "POST",
        url: "./ajax/cotizacion/agregar_facturacion.php",
        data: "id=" + id + "&precio_venta=" + precio_venta + "&cantidad=" + cantidad,
        beforeSend: function (objeto) {
            $("#resultados").html("Mensaje: Cargando...");
        },
        success: function (datos) {
            $("#resultados").html(datos);
            var obj = document.getElementById("btn_modalEditarFactura");
            obj.click();
        }
    });
}


function agregarProducto(id) {
    var precio_venta = document.getElementById('precio_venta_' + id).value;
    var cantidad = document.getElementById('cantidad_' + id).value;
    var costo = document.getElementById('costo_producto_' + id).value;
    var stock = document.getElementById('stock_' + id).value;
    var nivel = document.getElementById('nivel').value;
    var precio1 = document.getElementById('precio1_' + id).value;
    if (nivel == 1 && parseFloat(precio_venta) < parseFloat(precio1))
    {
        alert('El precio no puede ser menor que el precio 1');
        document.getElementById('precio_venta' + id).focus();
        return false;
    }

    if (parseFloat(precio_venta) < parseFloat(costo))
    {
        alert('El precio no puede ser menor que el costo');
        document.getElementById('precio_venta' + id).focus();
        return false;
    }
    if (isNaN(cantidad))
    {
        alert('Esto no es un numero');
        document.getElementById('cantidad_' + id).focus();
        return false;
    }
    if (isNaN(precio_venta))
    {
        alert('Esto no es un numero');
        document.getElementById('precio_venta_' + id).focus();
        return false;
    }
//Fin validacion

    $.ajax({
        type: "POST",
        url: "./ajax/cotizacion/agregar_facturacion.php",
        data: "id=" + id + "&precio_venta=" + precio_venta + "&cantidad=" + cantidad,
        beforeSend: function (objeto) {
            $("#resultados").html("Mensaje: Cargando...");
        },
        success: function (datos) {
            $("#resultados").html(datos);
            //validar el boton de procesar
            var check = document.getElementById('check').value;
            if (check == "true")
            {
                $("#procesar").attr("disabled", true);
            } else
            {
                $("#procesar").attr("disabled", false);
            }
        }
    });
}

function agregarCotizacion(id) {
    $.ajax({
        type: "POST",
        url: "./ajax/cotizacion/agregar_cotizacion.php",
        data: "id=" + id + "&parametro=agregarCotizacion",
        beforeSend: function (objeto) {
            $("#resultados").html("Mensaje: Cargando...");
        },
        success: function (datos) {
            $("#resultados").html(datos);
            var total = document.getElementById('total').value;
            if (total !== '0.00')
            {
                $("#procesar").attr("disabled", false);
            }
            var check = document.getElementById("check").value;
            if (check == "true") {
                $("#procesar").attr("disabled", true);
            }
        }
    });
}

function agregarCotizacionEspera(id, nom, te, di, cod, fo, tem, val, nota) {
    $.ajax({
        type: "POST",
        url: "./ajax/cotizacion/agregar_cotizacion_espera.php",
        data: "id=" + id + "&parametro=agregarCotizacion",
        beforeSend: function (objeto) {
            $("#resultados").html("Mensaje: Cargando...");
        },
        success: function (datos) {
            $("#resultados").html(datos);
            var total = document.getElementById('total').value;
            if (total !== '0.00')
            {
                $("#procesar").attr("disabled", false);
            }
            var check = document.getElementById("check").value;
            if (check == "true") {
                $("#procesar").attr("disabled", true);
            }
            document.getElementById("codigo_cliente").value = cod;
            document.getElementById("nombre_cliente").value = nom;
            document.getElementById("tel1").value = te;
            document.getElementById("direccion_cliente").value = di;
            document.getElementById("cod_cotizacion").value = id;
            document.getElementById("forma_pago").value = fo;
            document.getElementById("validez").value = val;
            document.getElementById("tiempo_entrega").value = tem;
            document.getElementById("otros").value = nota;
        }
    });
}

function eliminar(id) {
    $.ajax({
        type: "POST",
        url: "./ajax/cotizacion/agregar_facturacion.php",
        data: "id=" + id,
        beforeSend: function (objeto) {
            $("#resultados").html("Mensaje: Cargando...");
        },
        success: function (datos) {
            $("#resultados").html(datos);
            //validar el boton de procesar
            var total = document.getElementById('total').value;
            if (total !== '0.00')
            {
                $("#procesar").attr("disabled", false);
            } else
                $("#procesar").attr("disabled", true);
            var check = document.getElementById("check").value;
            if (check == "true") {
                $("#procesar").attr("disabled", true);
            }
        }
    });
}

$("#datos_cotizacion").submit(function () {
//datos de la cotizacion
//var num_cotizacion = document.getElementById('num_cotizacion').value;
    var id_cliente = document.getElementById('codigo_cliente').value;
    var condicion = document.getElementById('forma_pago').value;
    var telefono = document.getElementById('tel1').value;
    var direccion = document.getElementById('direccion_cliente').value;
    var impuesto = document.getElementById('impuesto').value;
    var subtotal = document.getElementById('subtotal').value;
    var total = document.getElementById('total').value;
    var cod_cotizacion = document.getElementById('cod_cotizacion').value;
    if (telefono == "" || direccion == "")
    {
        alert("Debe seleccionar un cliente");
        return false;
    }
//guardar cotizacion en la BD
    var parametros = $(this).serialize();
    $.ajax({
        type: "POST",
        url: 'ajax/cotizacion/nueva_cotizacion.php?impuesto=' + impuesto + '&subtotal=' + subtotal + '&total=' + total + '&cod_cotizacion=' + cod_cotizacion,
        data: parametros,
        beforeSend: function (objeto) {
            $('#resultados').html('<img src="./public/imagenes/ajax-loader.gif"> Cargando...');
            //VentanaCentrada('pdf/documentos/ver_cotizacion.php?id_cotizacion='+num_cotizacion,'Cotizacion','','1024','768','true');
        }, success: function (datos) {

            //Generar PDF y mostrar cotizacion en pantalla
            var data = eval(datos);
            //Se trae en formato json el id de la ultima cotizacion registrada
            var id_ult_cot = data;
            $.ajax({
                type: "GET",
                url: 'pdf/documentos/ver_cotizacion.php?id_cotizacion=' + id_ult_cot,
                beforeSend: function (objeto) {
                    $('#resultados').html('<img src="./public/imagenes/ajax-loader.gif"> Generando cotización...');
                },
                success: function (datos) {
                    location.href = "cotizacion";
                }
            });
        }
    });
    event.preventDefault();
});
$("#guardar_cliente").submit(function (event) {
    $('#guardar_datos').attr("disabled", false);
    var parametros = $(this).serialize();
    $.ajax({
        type: "POST",
        url: "ajax/cliente/nuevo_cliente.php",
        data: parametros,
        beforeSend: function (objeto) {
            $("#resultados_ajax").html("Mensaje: Cargando...");
        },
        success: function (datos) {
            $("#resultados_ajax").html(datos);
            //valor del input oculto que se crea en ajax/nuevo_cliente.php, 1 si se registra el cliente y 0 si ya existe
            var bool = $('#bool').val();
            if (bool == '1')
            {
                $('#codigo_cliente').val($('#codigo').val());
                $('#nombre_cliente').val($('#nombre').val());
                $('#tel1').val($('#telefono').val());
                $('#direccion_cliente').val($('#direccion').val());
                var obj = document.getElementById("btn_modalCliente");
                obj.click();
            }
            $('#guardar_datos').attr("disabled", false);
            document.getElementById('guardar_cliente').reset();
            load(1);
        }
    });
    event.preventDefault();
})

$("#guardar_producto").submit(function (event) {
    $('#guardar_datos').attr("disabled", false);
    var parametros = $(this).serialize();
    if ($('#departamento').val() !== 'null') {
        $.ajax({
            type: "POST",
            url: "ajax/producto/nuevo_producto.php",
            data: parametros,
            beforeSend: function (objeto) {
                $("#resultados_ajax_productos").html("Mensaje: Cargando...");
            },
            success: function (datos)
            {
                $("#resultados_ajax_productos").html(datos);
                $('#guardar_datos').attr("disabled", false);
                $('#codigo').focus();
                var bool = $('#bool').val();
                if (bool == '1')
                {
                    $.ajax({
                        type: "POST",
                        url: "./ajax/cotizacion/crear_producto.php",
                        data: parametros,
                        beforeSend: function (objeto)
                        {
                            $("#resultados").html("Mensaje: Cargando...");
                        },
                        success: function (datos)
                        {
                            $("#resultados").html(datos);
                            document.getElementById("guardar_producto").reset();
                            //validar el boton de procesar
                            var total = document.getElementById('total').value;
                            if (total !== '0.00')
                            {
                                $("#procesar").attr("disabled", false);
                            } else
                                $("#procesar").attr("disabled", true);
                        }
                    });
                    var obj = document.getElementById("btn_modalProducto");
                    obj.click();
                }
            }
        });
    } else {
        var div = '<div class="alert alert-danger" role="alert">'
                + '<button type="button" class="close" data-dismiss="alert">&times;</button>'
                + '<strong>Debe Seleccionar un Departamento</strong> '
                + '</div>';
        $('#resultados_ajax_productos').html(div);
    }
    event.preventDefault();
})

function limpiar_modal() {

    $("#resultados_ajax_productos").html("");
    $("#resultados_ajax").html("");
    document.getElementById("guardar_producto").reset();
    document.getElementById("guardar_proveedor").reset();
}

function cotizacion_espera() {
    var cod_cliente = document.getElementById('codigo_cliente').value;
    if (cod_cliente != "")
    {
//guardar la cotizacion en la tabla temporal
        var cod_cotizacion = document.getElementById('cod_cotizacion').value;
        var impuesto = "0";
        var subtotal = "0";
        var total = "0";
        var forma_pago = document.getElementById('forma_pago').value;
        var tiempo_entrega = document.getElementById('tiempo_entrega').value;
        var validez = document.getElementById('validez').value;
        var otros = document.getElementById('otros').value;
        if ($('#impuesto').length) {
            impuesto = document.getElementById('impuesto').value;
            subtotal = document.getElementById('subtotal').value;
            total = document.getElementById('total').value;
            if (total !== '0.00') {
                $.ajax({
                    type: "POST",
                    url: "ajax/cotizacion/cotizacion_espera.php",
                    data: "impuesto=" + impuesto + "&subtotal=" + subtotal + "&total=" + total + "&codigo_cliente=" + cod_cliente +
                            "&forma_pago=" + forma_pago + "&tiempo_entrega=" + tiempo_entrega + "&validez=" + validez + "&otros=" + otros +
                            "&cod_cotizacion=" + cod_cotizacion,
                    beforeSend: function (objeto) {
                    }, success: function (datos) {
                        $('#cod_cotizacion').attr("value", datos[1]);
                        capa = document.getElementById('mensaje');
                        capa.style.display = 'block';
                    }
                });
            } else {
                alert("No hay datos para guardar");
            }
        } else {
            alert("No hay datos para guardar");
        }

    } else {
        alert("No hay datos para guardar");
    }
}

function cargar_cotizaciones_espera(page) {

    var q = $("#bce").val();
    $("#cargarEspera").fadeIn('slow');
    $.ajax({
        url: './ajax/cotizacion/cargar_cotizaciones_espera.php?action=ajax&page=' + page + '&q=' + q,
        beforeSend: function (objeto) {
            $('#cargarEspera').html('<img src="./public/imagenes/ajax-loader.gif"> Cargando...');
        },
        success: function (data) {
            $(".datosEspera").html(data).fadeIn('slow');
            $('#cargarEspera').html('');
        }
    });
}

function retomar_cotizacion() {
    cargar_cotizaciones_espera(1);
}

function cargar_cotizaciones(page) {

    var q = $("#bc").val();
    $("#cargarEspera").fadeIn('slow');
    $.ajax({
        url: './ajax/cotizacion/cargar_cotizaciones.php?action=ajax&page=' + page + '&q=' + q,
        beforeSend: function (objeto) {
            $('#cargar').html('<img src="./public/imagenes/ajax-loader.gif"> Cargando...');
        },
        success: function (data) {
            $(".otro").html(data).fadeIn('slow');
            $('#cargar').html('');
        }
    })
}

function cotizacion() {
    cargar_cotizaciones(1);
}

function cargar_producto(page) {
    var q = $("#q").val();
    var dp = $("#dp").val();
    $("#loader").fadeIn('slow');
    $.ajax({
        url: './ajax/cotizacion/productos_cotizacion.php?action=ajax&page=' + page + '&q=' + q + "&dp=" + dp,
        beforeSend: function (objeto) {
            $('#loader').html('<img src="./public/imagenes/ajax-loader.gif"> Cargando...');
        },
        success: function (data) {
            var prec = document.createElement('input');
            prec.class = 'form-control';
            prec.value = 11.05;

            $(".outer_div").html(data).fadeIn('slow');
            $('#loader').html('');
            data = [{"codigo": "ACCE0", "descripcion": "Accesorio de prueba", "estatus": "1", "enser": "1", "tipo": "1", "costo": 0.005, "precio1": 10, "precio2": 20, "precio3": 30, "cantidad": 2}, {"codigo": "ACCE019", "descripcion": "CONVERTIDOR ADAPTADOR SATA\/IDE A USB", "estatus": "1", "enser": "0", "tipo": "1", "costo": 30.88, "precio1": 25, "precio2": 30, "precio3": 35, "cantidad": 1}, {"codigo": "ACCE042", "descripcion": "BATERIA PARA BIOS MOD. CR2032 LITIO", "estatus": "1", "enser": "0", "tipo": "1", "costo": 30, "precio1": 25, "precio2": 30, "precio3": 35, "cantidad": 1}, {"codigo": "ACCE043", "descripcion": "PILA AAA GP 1.2 V HHR-55AAABU BLISTER DE 2 BATERIAS", "estatus": "1", "enser": "0", "tipo": "1", "costo": 2, "precio1": 25, "precio2": 30, "precio3": 35, "cantidad": 1}, {"codigo": "ACCE13", "descripcion": "MOUSE OPTICO USB, MEDIANO", "estatus": "1", "enser": "0", "tipo": "1", "costo": 700, "precio1": 25, "precio2": 30, "precio3": 35, "cantidad": 2}, {"codigo": "ACCE2", "descripcion": "COMBO TECLADO GIO Y RATON DELL USB", "estatus": "1", "enser": "0", "tipo": "1", "costo": 279.51, "precio1": 25, "precio2": 30, "precio3": 35, "cantidad": 2}, {"codigo": "ACCE5", "descripcion": "CABLE UTP CAT.5E, AL DETAL", "estatus": "1", "enser": "0", "tipo": "1", "costo": 0.23846, "precio1": 25, "precio2": 30, "precio3": 35, "cantidad": 282}, {"codigo": "ACCE51", "descripcion": "BATERIA TIPO AA, MARCA MAXXELL ALKALINA, INDIVIDUAL", "estatus": "1", "enser": "0", "tipo": "1", "costo": 0.75, "precio1": 25, "precio2": 30, "precio3": 35, "cantidad": 2}, {"codigo": "ACCE52", "descripcion": "BATERIA TIPO AAA, MARCA MAXXELL ALKALINA, INDIVIDUAL", "estatus": "1", "enser": "0", "tipo": "1", "costo": 0.76, "precio1": 25, "precio2": 30, "precio3": 35, "cantidad": 2}, {"codigo": "ACCE78", "descripcion": "ESTUCHE MARCA CASE LOGIC", "estatus": "1", "enser": "0", "tipo": "1", "costo": 41.6, "precio1": 25, "precio2": 30, "precio3": 35, "cantidad": 3}, {"codigo": "COM028", "descripcion": "MONITOR AOC LED 19.5\"", "estatus": "1", "enser": "0", "tipo": "1", "costo": 46.5, "precio1": 25, "precio2": 30, "precio3": 35, "cantidad": 1}, {"codigo": "COM081", "descripcion": "MONITOR MARCA DELL, HP O LG 17\" LCD CLASE A ", "estatus": "1", "enser": "0", "tipo": "1", "costo": 50, "precio1": 25, "precio2": 30, "precio3": 35, "cantidad": 1}, {"codigo": "COMP014", "descripcion": "COMPUTADOR HP ELITE 8000 PROCESADOR INTEL CORE2DUO DE 3.0 GHZ, RAM 2 GB DDR3 DISCO DURO 1TB, UNIDAD DVD-RW, REFURBISHED INCLUYE TECL Y MOUSE NUEVOS", "estatus": "1", "enser": "0", "tipo": "1", "costo": 148, "precio1": 25, "precio2": 30, "precio3": 35, "cantidad": 1}, {"codigo": "COMP59", "descripcion": "DISCO DURO, DE 2,5\", CAPACIDAD 250GB", "estatus": "1", "enser": "0", "tipo": "1", "costo": 43.68, "precio1": 25, "precio2": 30, "precio3": 35, "cantidad": 1}, {"codigo": "CONS011", "descripcion": "CARTUCHO HP 60 COLOR ", "estatus": "1", "enser": "0", "tipo": "1", "costo": 4500, "precio1": 25, "precio2": 30, "precio3": 35, "cantidad": 2}, {"codigo": "CONS012", "descripcion": "CARTUCHO HP 60 NEGRO", "estatus": "1", "enser": "0", "tipo": "1", "costo": 4500, "precio1": 25, "precio2": 30, "precio3": 35, "cantidad": 2}, {"codigo": "MOBI1", "descripcion": "SILLA, MODELO ROMA, COLOR NEGRO", "estatus": "1", "enser": "1", "tipo": "1", "costo": 0, "precio1": 0, "precio2": 0, "precio3": 0, "cantidad": 2}, {"codigo": "MOBI3", "descripcion": "CERRADURA DE PUERTA, MARCA GATER, SIN LLAVE Y 1 TORNILLO", "estatus": "1", "enser": "1", "tipo": "1", "costo": 0, "precio1": 0, "precio2": 0, "precio3": 0, "cantidad": 1}, {"codigo": "MOBI4", "descripcion": "CARTUCHO MARCA HP, MODELO GLOBALOFFICE, COLOR NEGRO", "estatus": "1", "enser": "1", "tipo": "1", "costo": 0, "precio1": 0, "precio2": 0, "precio3": 0, "cantidad": 1}, {"codigo": "OFIC0", "descripcion": "RESALTADOR, MARCA KORES, COLOR AMARILLO", "estatus": "1", "enser": "1", "tipo": "1", "costo": 0, "precio1": 0, "precio2": 0, "precio3": 0, "cantidad": 4}, {"codigo": "OFIC1", "descripcion": "RESALTADOR, MARCA SHARPIE, MODELO ACCENT 3D. COLOR AMARILLO", "estatus": "1", "enser": "1", "tipo": "1", "costo": 0, "precio1": 0, "precio2": 0, "precio3": 0, "cantidad": 3}, {"codigo": "OFIC10", "descripcion": "LAPICERO MARCA PAPERMATE, MODELO KILOMETRICO, COLOR AZUL.", "estatus": "1", "enser": "1", "tipo": "1", "costo": 0, "precio1": 0, "precio2": 0, "precio3": 0, "cantidad": 4}, {"codigo": "OFIC11", "descripcion": "LAPICERO MARCA KORES, MODELO K-PEN, COLOR AZUL", "estatus": "1", "enser": "1", "tipo": "1", "costo": 0, "precio1": 0, "precio2": 0, "precio3": 0, "cantidad": 7}, {"codigo": "OFIC12", "descripcion": "LAPICERO MARCA PAPERMATE, MODELO KILOM\u00c9TRICO, COLOR NEGRO.", "estatus": "1", "enser": "1", "tipo": "1", "costo": 0, "precio1": 0, "precio2": 0, "precio3": 0, "cantidad": 12}, {"codigo": "OFIC13", "descripcion": "LAPIZ DE GRAFITO, MARCA MONGOL MODELO PAPERMATE.", "estatus": "1", "enser": "1", "tipo": "1", "costo": 0, "precio1": 0, "precio2": 0, "precio3": 0, "cantidad": 4}, {"codigo": "OFIC14", "descripcion": "LAPIZ DE GRAFITO, MARCA PRISMACOLOR, MODELO TURQUOISE H.", "estatus": "1", "enser": "1", "tipo": "1", "costo": 0, "precio1": 0, "precio2": 0, "precio3": 0, "cantidad": 8}, {"codigo": "OFIC15", "descripcion": "CORRECTOR OFIART MODELO PLUMA.", "estatus": "1", "enser": "1", "tipo": "1", "costo": 0, "precio1": 0, "precio2": 0, "precio3": 0, "cantidad": 1}, {"codigo": "OFIC16", "descripcion": "CLIP DE METAL, MARCA OFIMAX.", "estatus": "1", "enser": "1", "tipo": "1", "costo": 0, "precio1": 0, "precio2": 0, "precio3": 0, "cantidad": 1}, {"codigo": "OFIC17", "descripcion": "CLIP DE METAL, MARCA PRINTA", "estatus": "1", "enser": "1", "tipo": "1", "costo": 0, "precio1": 0, "precio2": 0, "precio3": 0, "cantidad": 2}, {"codigo": "OFIC18", "descripcion": "ROLL ALMOHADILLA, MARCA LIDERPER. (TINTA PARA SELLOS).", "estatus": "1", "enser": "1", "tipo": "1", "costo": 0, "precio1": 0, "precio2": 0, "precio3": 0, "cantidad": 1}, {"codigo": "OFIC19", "descripcion": "PEGA EN BARRA, MARCA RULIETTA.", "estatus": "1", "enser": "1", "tipo": "1", "costo": 0, "precio1": 0, "precio2": 0, "precio3": 0, "cantidad": 1}, {"codigo": "OFIC2", "descripcion": "RESALTADOR, MARCA KORES, MODELO BRINHT LINER, COLOR VERDE", "estatus": "1", "enser": "1", "tipo": "1", "costo": 0, "precio1": 0, "precio2": 0, "precio3": 0, "cantidad": 3}, {"codigo": "OFIC20", "descripcion": "CELOVEN PEQUE\u00d1O", "estatus": "1", "enser": "1", "tipo": "1", "costo": 0, "precio1": 0, "precio2": 0, "precio3": 0, "cantidad": 2}, {"codigo": "OFIC21", "descripcion": "GANCHOS PARA CARPETAS, MARCA PRESTO.", "estatus": "1", "enser": "1", "tipo": "1", "costo": 0, "precio1": 0, "precio2": 0, "precio3": 0, "cantidad": 38}, {"codigo": "OFIC22", "descripcion": "CLIP DE METAL, MARCA ITECA, MODELO MARIPOSA.", "estatus": "1", "enser": "1", "tipo": "1", "costo": 0, "precio1": 0, "precio2": 0, "precio3": 0, "cantidad": 9}, {"codigo": "OFIC23", "descripcion": "CINTA DOBLE FAX, MARCA MOUNTING TAPE.", "estatus": "1", "enser": "1", "tipo": "1", "costo": 0, "precio1": 0, "precio2": 0, "precio3": 0, "cantidad": 1}, {"codigo": "OFIC24", "descripcion": "FICHAS DE CARPETAS, MARCA RECARGATE.", "estatus": "1", "enser": "1", "tipo": "1", "costo": 0, "precio1": 0, "precio2": 0, "precio3": 0, "cantidad": 24}, {"codigo": "OFIC25", "descripcion": "PEGA BARRA, MARCA ARTESCO.", "estatus": "1", "enser": "1", "tipo": "1", "costo": 0, "precio1": 0, "precio2": 0, "precio3": 0, "cantidad": 1}, {"codigo": "OFIC26", "descripcion": "PAPEL CARBON, MARCA KORES, MODELO TYPO\/1200, COLOR NEGRO", "estatus": "1", "enser": "1", "tipo": "1", "costo": 0, "precio1": 0, "precio2": 0, "precio3": 0, "cantidad": 100}, {"codigo": "OFIC27", "descripcion": "SOBRES MODELO MANILA, TIPO OFICIO, COLOR VERDE", "estatus": "1", "enser": "1", "tipo": "1", "costo": 0, "precio1": 0, "precio2": 0, "precio3": 0, "cantidad": 16}, {"codigo": "OFIC28", "descripcion": "SOBRE MANILA, MARCA OFIMAX, COLOR AMARILLO.", "estatus": "1", "enser": "1", "tipo": "1", "costo": 0, "precio1": 0, "precio2": 0, "precio3": 0, "cantidad": 62}, {"codigo": "OFIC29", "descripcion": "CARPETA DE PRESENTACION, TALENTO E INNOVACION.", "estatus": "1", "enser": "1", "tipo": "1", "costo": 0, "precio1": 0, "precio2": 0, "precio3": 0, "cantidad": 8}, {"codigo": "OFIC3", "descripcion": "RESALTADOR, MARCA KORES, COLOR NARANJA", "estatus": "1", "enser": "1", "tipo": "1", "costo": 0, "precio1": 0, "precio2": 0, "precio3": 0, "cantidad": 3}, {"codigo": "OFIC4", "descripcion": "MARCADOR MOMARCA SHARPIE, MODELO REDONDO, COLOR NEGRO", "estatus": "1", "enser": "1", "tipo": "1", "costo": 0, "precio1": 0, "precio2": 0, "precio3": 0, "cantidad": 10}, {"codigo": "OFIC5", "descripcion": "MARCADOR MARCA EXPO MODELO REDONDO ACRILICO, COLOR NEGRO.", "estatus": "1", "enser": "1", "tipo": "1", "costo": 0, "precio1": 0, "precio2": 0, "precio3": 0, "cantidad": 2}, {"codigo": "OFIC6", "descripcion": "MARCADOR MARCA EXPO MODELO REDONDO ACRILICO, COLOR AZUL.", "estatus": "1", "enser": "1", "tipo": "1", "costo": 0, "precio1": 0, "precio2": 0, "precio3": 0, "cantidad": 3}, {"codigo": "OFIC7", "descripcion": "MARCADOR MARCA EXPO, MODELO REDONDO ACRILICO, COLOR ROJO.", "estatus": "1", "enser": "1", "tipo": "1", "costo": 0, "precio1": 0, "precio2": 0, "precio3": 0, "cantidad": 2}, {"codigo": "OFIC8", "descripcion": "MARCADOR MARCA PRO, MODELO SIGNAL COLOR NEGRO.", "estatus": "1", "enser": "1", "tipo": "1", "costo": 0, "precio1": 0, "precio2": 0, "precio3": 0, "cantidad": 1}, {"codigo": "OFIC9", "descripcion": "LAPICERO MARCA KORES MODELO K-PEN COLOR NEGRO.", "estatus": "1", "enser": "1", "tipo": "1", "costo": 0, "precio1": 0, "precio2": 0, "precio3": 0, "cantidad": 1}, {"codigo": "SEGU27", "descripcion": "CAPTA HUELLAS (BIOMETRICO, MARCA ANVIZ, MODELO EP300", "estatus": "1", "enser": "0", "tipo": "1", "costo": 21000, "precio1": 25, "precio2": 30, "precio3": 35, "cantidad": 1}, {"codigo": "SER005", "descripcion": "MANTENIMIENTO, LIMPIEZA E INSTALACI\u00d3N DE SOFTWARE EN EQUIPO DE COMPUTACION", "estatus": "1", "enser": "0", "tipo": "2", "costo": 14.23076923, "precio1": 25, "precio2": 30, "precio3": 35, "cantidad": 2}, {"codigo": "SER007", "descripcion": "MANTENIMIENTO PC EN EL SITIO (SOPLADO Y LIMPIEZA)", "estatus": "1", "enser": "0", "tipo": "2", "costo": 18, "precio1": 25, "precio2": 30, "precio3": 35, "cantidad": 3}, {"codigo": "SER011", "descripcion": "REPARACION Y MANTENIMIENTO DE LAPTOP", "estatus": "1", "enser": "0", "tipo": "2", "costo": 1.92308, "precio1": 25, "precio2": 30, "precio3": 35, "cantidad": 1}, {"codigo": "SERV001", "descripcion": "HORA DE SERVICIO T\u00c9CNICO EN EL SITIO ", "estatus": "1", "enser": "0", "tipo": "2", "costo": 11.53846153, "precio1": 25, "precio2": 30, "precio3": 35, "cantidad": 1}, {"codigo": "SERV004", "descripcion": "MANTENIMIENTO GENERAL, CALIBRACION DE PARAMETROS PUESTA EN MARCHA A UPS DE 3KVA (GARANTIA TRES (03) MESES POR DEFECTO DE FABRICA)", "estatus": "1", "enser": "0", "tipo": "2", "costo": 4, "precio1": 25, "precio2": 30, "precio3": 35, "cantidad": 1}, {"codigo": "SPTC10", "descripcion": "MANTENIMIENTO PREVENTIVO DE 16 EQUIPOS DE COMPUTACI\u00d3N EST\u00c1NDAR, MAS LIMPIEZA, SOPLADO INTERNO Y LIMPIEZA EXTERNA CON PRODUCTOS QU\u00cdMICOS AL CASE.", "estatus": "1", "enser": "0", "tipo": "2", "costo": 275.6923, "precio1": 25, "precio2": 30, "precio3": 35, "cantidad": 2}, {"codigo": "SPTC3", "descripcion": "SOPORTE BASICO Y REVISION DE EQUIPO (HORA TECNICA)", "estatus": "1", "enser": "0", "tipo": "2", "costo": 9, "precio1": 25, "precio2": 30, "precio3": 35, "cantidad": 1}, {"codigo": "UPS0022", "descripcion": "UPS MARCA FORZA 500VA 250W. MOD. NT-501, GARANTIA DE 1 A\u00d1O", "estatus": "1", "enser": "0", "tipo": "1", "costo": 36.5, "precio1": 25, "precio2": 30, "precio3": 35, "cantidad": 3}, {"codigo": "UPS044", "descripcion": "UPS MARCA EMERALD, BACKUPS Y REGULADOR. MOD. SQ-500, DE 500VA Y 4 TOMAS. GARANTIA 3 MESES", "estatus": "1", "enser": "0", "tipo": "1", "costo": 18.8, "precio1": 25, "precio2": 30, "precio3": 35, "cantidad": 3}];
            var tb = document.getElementById('prueba');
            prueba = new Tabla(tb,
                    ['Codigo', 'Producto', 'Cant', 'Precio', 'Agregar'],
                    data,
                    ['codigo', 'Descripcion', 'Cant', 'Precio', 'status'],
                    5);
            prueba.columZise([10, 60, 10, 10, 10]);
            prueba.columAling(['center', 'center', 'center', 'center', 'right']);
            prueba.cellcuston('status', function (obj) {
                var html = '<button onclick="agregar(' + obj + ')"/><span class="icon-pluss"></span></button>';
                return html;
            });
            prueba.head = false;
            prueba.cellcuston('Precio', function (obj) {
                var html = '';
                html += '';
                html += ' <a href="#' + obj.codigo + '">' + obj.codigo + '</a>';
                return html;
            });
            prueba.ordenar(0, 'd');
            prueba.search(['codigo', 'nombre']);
        }
    });
}

function producto() {
    cargar_producto(1);
}
