<?php
 include '../../config/seccion.php';
  if(empty($_SESSION['usuario']))
  {
    header('Location: index.php');
  }  




		/* Conectar a la base de datos*/
		include '../../../config/conexion.php';

		$codigo =$con->real_escape_string((strip_tags($_POST["codigo"],ENT_QUOTES)));
		$descripcion =$con->real_escape_string((strip_tags($_POST["edit_descripcion"],ENT_QUOTES)));

		$sql = $con->query("SELECT *from tipo_producto WHERE codigo = '$codigo'");

		if ($row=$sql->fetch_array()) 
		{

			$sql = "UPDATE tipo_producto SET descripcion = UPPER('$descripcion') WHERE codigo = '$codigo' ";
			$query = $con->query($sql);
				if ($query)
				{
					$messages[] = "Modificado satisfactoriamente.";
				}			
		}

?>