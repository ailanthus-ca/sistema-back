<?php

session_start();
if (empty($_SESSION['usuario'])) {
    header('Location: index.php');
}
$id_usuario = $_SESSION['id_usuario'];
/* Conectar a la base de datos */
include '../../config/conexion.php';

$tmp_cotizacion = $con->real_escape_string((strip_tags($_POST["cod_cotizacion"], ENT_QUOTES)));
$codigo_cliente = $con->real_escape_string((strip_tags($_POST["codigo_cliente"], ENT_QUOTES)));
$fecha = date('Y-m-d');
$impuesto = (isset($_REQUEST['impuesto']) && $_REQUEST['impuesto'] != NULL) ? $_REQUEST['impuesto'] : '';
//Reemplazo las comas
$impuesto_r = str_replace(",", "", $impuesto);
$subtotal = (isset($_REQUEST['subtotal']) && $_REQUEST['subtotal'] != NULL) ? $_REQUEST['subtotal'] : '';
//Reemplazo las comas
$subtotal_r = str_replace(",", "", $subtotal);
$total = (isset($_REQUEST['total']) && $_REQUEST['total'] != NULL) ? $_REQUEST['total'] : '';
//Reemplazo las comas
$total_r = str_replace(",", "", $total);

$forma_pago = $con->real_escape_string((strip_tags($_POST["forma_pago"], ENT_QUOTES)));
$tiempo_entrega = $con->real_escape_string((strip_tags($_POST["tiempo_entrega"], ENT_QUOTES)));
$validez = $con->real_escape_string((strip_tags($_POST["validez"], ENT_QUOTES)));
$otros = $con->real_escape_string((strip_tags($_POST["otros"], ENT_QUOTES)));


if ($codigo_cliente != "" && $fecha != "" && $impuesto != "" && $subtotal != "" && $total != "") {
    $sql = "INSERT into cotizacion values('',UPPER('$codigo_cliente'), '$fecha', $impuesto_r, $subtotal_r, $total_r, UPPER('$forma_pago'), UPPER('$tiempo_entrega'), UPPER('$validez'), UPPER('$otros'), 1,$id_usuario)";
    $query = $con->query($sql);
}
$id_cotizacion_ult = $con->insert_id;
$sql = $con->query("select * from tmp_cot_prod WHERE usuario_tmp = '$id_usuario'");
while ($row = $sql->fetch_array()) {
    echo "INSERT INTO detallecotizacion VALUES ('$id_cotizacion_ult','" . $row['id_producto'] . "','" . $row['cantidad_tmp'] . "', '" . $row['precio_tmp'] . "', '" . $row['precio_tmp'] * $row['cantidad_tmp'] . "', '" . $row['descripcion_tmp'] . "') ";
    $con->query("INSERT INTO detallecotizacion VALUES ('$id_cotizacion_ult','" . $row['id_producto'] . "','" . $row['cantidad_tmp'] . "', '" . $row['precio_tmp'] . "', '" . $row['precio_tmp'] * $row['cantidad_tmp'] . "', '" . $row['descripcion_tmp'] . "') ");
}
if ($tmp_cotizacion != "-1") {
    $sql = "DELETE FROM tmp_cotizacion WHERE codigo=$tmp_cotizacion";
    $query = $con->query($sql);
    $sql = "DELETE FROM tmp_detalle_cotizacion WHERE codCotizacion = $tmp_cotizacion";
    $query = $con->query($sql);
}
$con->query("DELETE from tmp_cot_prod WHERE usuario_tmp = '$id_usuario'");
echo json_encode($id_cotizacion_ult);
mysqli_close($con);
?>