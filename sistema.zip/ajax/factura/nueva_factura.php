<?php

session_start();
$id_user = $_SESSION['id_usuario'];
if (empty($_SESSION['usuario'])) {
    header('Location: index.php');
}






/* Conectar a la base de datos */
include '../../config/conexion.php';



$id_factura = $num_factura = $con->real_escape_string((strip_tags($_POST["num_factura"], ENT_QUOTES)));
$codigo_cliente = $con->real_escape_string((strip_tags($_POST["codigo_cliente"], ENT_QUOTES)));
$condicion = $con->real_escape_string((strip_tags($_POST["condicion"], ENT_QUOTES)));
$observacion = $con->real_escape_string((strip_tags($_POST["observacion"], ENT_QUOTES)));
$fecha = date('Y-m-d');
$porc_impuesto = (isset($_REQUEST['porc_impuesto']) && $_REQUEST['porc_impuesto'] != NULL) ? $_REQUEST['porc_impuesto'] : '';
$costo_total = $_GET['costo_total'];
$impuesto = (isset($_REQUEST['impuesto']) && $_REQUEST['impuesto'] != NULL) ? $_REQUEST['impuesto'] : '';
//Reemplazo las comas	
$impuesto_r = str_replace(",", "", $impuesto);
$subtotal = (isset($_REQUEST['subtotal']) && $_REQUEST['subtotal'] != NULL) ? $_REQUEST['subtotal'] : '';
//Reemplazo las comas
$subtotal_r = str_replace(",", "", $subtotal);
$total = (isset($_REQUEST['total']) && $_REQUEST['total'] != NULL) ? $_REQUEST['total'] : '';
//Reemplazo las comas
$total_r = str_replace(",", "", $total);
$id_cotizacion = (isset($_REQUEST['id_cotizacion']) && $_REQUEST['id_cotizacion'] != NULL) ? $_REQUEST['id_cotizacion'] : '';


//si se cargo una cotizacion entonces actualiza el estatus de esa cotizacion para que quede como procesada
if ($id_cotizacion != '') {
    $sql = $con->query("UPDATE cotizacion SET estatus = 2 WHERE codigo = '$id_cotizacion' ");
    $sql = $con->query("select usuario from cotizacion WHERE codigo = '$id_cotizacion'");
    if ($row = $sql->fetch_array()) {
        $user = $row['usuario'];
    }
} else {
    $user = $_SESSION['id_usuario'];
}
if ($num_factura != "" && $codigo_cliente != "" && $fecha != "" && $impuesto != "" && $porc_impuesto != "" && $subtotal != "" && $total != "") {
    $sql = "INSERT into factura values($num_factura,UPPER('$codigo_cliente'), '$fecha', '$condicion',$porc_impuesto, $costo_total, $impuesto_r, $subtotal_r, $total_r, UPPER('$observacion'), $user ,2)";
    $query = $con->query($sql) or die("factura: " . mysqli_error());

    $sql = $con->query("select * from tmp_fact_prod") or die("tmp_fact_prod: " . mysqli_error());
    while ($row = $sql->fetch_array()) {
        $con->query("INSERT INTO detallefactura VALUES ('$num_factura','" . $row['id_producto'] . "','" . $row['cantidad_tmp'] . "', '" . $row['precio_tmp'] . "', '" . $row['precio_tmp'] * $row['cantidad_tmp'] . "') ") or die("detallefactura " . $row['id_producto'] . ": " . mysqli_error());
        $sql_pro = $con->query("SELECT tipo from producto WHERE codigo = '" . $row['id_producto'] . "' ") or die("producto SELECT" . $row['id_producto'] . ": " . mysqli_error());
        $row_pro = mysqli_fetch_array($sql_pro);
        $tipo = $row_pro['tipo'];
        if ($tipo == "1") {
            $con->query("UPDATE producto set cantidad = cantidad - ('" . $row['cantidad_tmp'] . "') WHERE codigo = '" . $row['id_producto'] . "' ") or die("producto UPDATE" . $row['id_producto'] . ": " . mysqli_error());
        }
    }
}
$con->query("TRUNCATE TABLE tmp_fact_prod");
echo 1;
?>

