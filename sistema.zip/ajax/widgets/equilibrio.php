<?php

/* Conectar a la base de datos */
include '../../config/conexion.php';

$mes_actual = date("n");
$ano_actual = date("Y");

$pto = (isset($_POST['pto']) && $_POST['pto'] != NULL) ? $_POST['pto'] : 'null';


if ($pto != "" AND $pto != NULL AND $pto != "null") {
    $con->query("INSERT into equilibrio values('',$ano_actual, $mes_actual, $pto)")
            or die('Error SQL ' . $sql . ' Mensaje:' . mysqli_error());

    $mes_anterior = $mes_actual - 1;
    if ($mes_anterior != 0) {
        echo 'sql';
        $sql = "SELECT * FROM mejor_mes WHERE mes=$mes_anterior AND año=$ano_actual";
    } else {
        echo 'sql';
        $año_anterior = $ano_actual - 1;
        $mes_anterior = 12;
        $sql = "SELECT * FROM mejor_mes WHERE mes=12 AND año=$año_anterior";
    }
    $query = $con->query($sql) or die('Error SQL ' . $sql . ' Mensaje:' . mysqli_error());
    if ($row = mysqli_fetch_array($query)) {
        echo 'existe';
    } else {
        echo 'crealo';
        $sql = "SELECT SUM(subtotal) AS ventas FROM factura WHERE estatus = 2 AND MONTH(fecha)=$mes_anterior AND YEAR(fecha)='$año_anterior'";
        $query = $con->query($sql) or die('Error SQL ' . $sql . ' Mensaje:' . mysqli_error());
        if ($row = mysqli_fetch_array($query)) {
            $con->query("INSERT INTO `mejor_mes`(`id`, `ventas`, `mes`, `año`) VALUES (null," . $row['ventas'] . ",$mes_anterior,$año_anterior)");
        }
    }
}
$sql_equi = $con->query("SELECT *from equilibrio WHERE ano = $ano_actual AND mes = $mes_actual") or die('Error SQL Mensaje:' . mysqli_error());
if ($row = mysqli_fetch_array($sql_equi)) {
    $equi = $row['monto'];
} else
    $equi = 0;
$sql_ventas = $con->query("SELECT SUM(subtotal) AS ventas FROM factura WHERE estatus = 2 AND MONTH(fecha)=$mes_actual AND YEAR(fecha)='$ano_actual'") or die('Error SQL Mensaje:' . mysqli_error());

if ($row2 = mysqli_fetch_array($sql_ventas)) {
    $ventas = $row2['ventas'];
}

$data = array(0 => $equi, 1 => $ventas);

echo json_encode($data);
?>
