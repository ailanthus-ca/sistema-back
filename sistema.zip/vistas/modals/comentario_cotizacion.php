	<!-- Modal -->
<div class="modal fade bs-example-modal-lg" id="comentario" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog modal-lg" role="document">
	<div class="modal-content">
	  <div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		<h4 class="modal-title" id="myModalLabel">Agregar comentario</h4>
	  </div>
	  <form>
	  <div class="modal-body">	  
	  <div id="resultado_comentario"></div>
	  <br><br><br><br><br>
		<div id="cargagif" style="position: absolute;	text-align: left;	top: 80px;	width: 100%;display:none;"></div><!-- Carga gif animado -->
		<div class="coment" ></div><!-- Datos ajax Final -->
		<br><br><br>
	  </div>
	  <div class="modal-footer">
	  <br><br><br>
		
	  </div>
	  </form>
	</div>
  </div>
</div>
