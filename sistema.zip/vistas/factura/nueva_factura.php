F<?php
include '../templates/template.php';
include '../../config/conexion.php';
if ($_SESSION['nivel'] == 1) {
    header('Location: panel_us');
}



//reinicia la tabla temporal que contiene productos de la factura anterior
$con->query("TRUNCATE TABLE tmp_fact_prod");

//comprobar si ya se ha configurado el numero de la factura
$sql = $con->query("SELECT *FROM conf_factura");

if ($row = $sql->fetch_array()) {
    //observacion de la factura
    $observacion = $row['observacion'];
    //si ya existen facturas en la bd, entonces se trae el codigo de la ultima factura registrada
    $sql = $con->query("SELECT *from factura");
    if ($row = $sql->fetch_array()) {
        $resultado = $con->query("SELECT MAX(codigo) as codigo from factura");
        $sum = 1;
    } else {
        //si no hay facturas registradas se trae el numero configurado de la bd
        $resultado = $con->query("SELECT num_factura as codigo from conf_factura");
        $sum = 0;
    }

    if ($row = mysqli_fetch_array($resultado)) {
        $cod_factura = $row['codigo'] + $sum;

        if (strlen($cod_factura) < 2)
            $cod_factura = "00000" . $cod_factura;
        if (strlen($cod_factura) < 3)
            $cod_factura = "0000" . $cod_factura;
        if (strlen($cod_factura) < 4)
            $cod_factura = "000" . $cod_factura;
        if (strlen($cod_factura) < 5)
            $cod_factura = "00" . $cod_factura;
        if (strlen($cod_factura) < 6)
            $cod_factura = "0" . $cod_factura;
    }
    $mensaje = '';
    $disabled = '';
}
else {

    $mensaje = '<div class="alert alert-danger" role="alert">
				  <button type="button" class="close" data-dismiss="alert">&times;</button>
				  <strong>¡Error!</strong>
					Debe inicializar el número de factura. Por favor vaya al modulo de configuración.
				  </div> ';
    $cod_factura = 000000;
    $disabled = 'disabled';
}

$conf = $con->query("SELECT *from conf_region");
if ($row = mysqli_fetch_array($conf)) {
    $impuesto1 = $row['impuesto'];
    $imp_esp = $row['imp_esp'];
}
?>

<br><br><br>
<input type="hidden" id="nivel" name="nivel" value="<?php echo $_SESSION['nivel'] ?>">
<div class="col-md-10 col-md-offset-1">
    <div class="panel panel-info">
        <div class="panel-heading">
            <h4><i class='glyphicon glyphicon-edit'></i> Nueva Factura </h4>
        </div>
        <div class="panel-body">
            <?php
            include("../modals/buscar_productos.php");
            include("../modals/buscar_cotizaciones.php");
            include("../modals/editar_factura.php");
            include("../modals/registro_clientes.php");
            ?>
            <form class="form-horizontal" role="form" id="datos_factura">
                <div><?php echo $mensaje; ?></div>
                <strong>Datos del cliente</strong>
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="form-group row">
                            <label for="codigo_cliente" class="col-md-1 control-label">RIF</label>
                            <div class="col-md-3">
                                <input type="text" class="form-control input-sm" id="codigo_cliente" name="codigo_cliente" placeholder="Ingresa el rif o cedula" required>
                                <input id="id_cliente" type='hidden'>	
                            </div>
                            <label for="nombre_cliente" class="col-md-1 control-label">Nombre</label>
                            <div class="col-md-3">
                                <input type="text" class="form-control input-sm" id="nombre_cliente" placeholder="nombre del cliente">
                            </div>
                            <label for="tel1" class="col-md-1 control-label">Teléfono</label>
                            <div class="col-md-2">
                                <input type="text" class="form-control input-sm" id="tel1" placeholder="Teléfono" readonly>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="direccion_cliente" class="col-md-1 control-label">Dirección</label>
                            <div class="col-md-10">
                                <input type="text" class="form-control input-sm" id="direccion_cliente" placeholder="Dirección" readonly> 	
                            </div>	 	
                        </div>				
                    </div>
                    <strong>Datos de la factura</strong>
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <div class="form-group row">
                                <label for="tel2" class="col-md-1 control-label">Numero</label>
                                <div class="col-md-2">
                                    <input type="text" class="form-control input-sm" id="num_factura" name="num_factura" value="<?php echo $cod_factura; ?>" readonly>	
                                </div>	
                                <label for="tel2" class="col-md-1 control-label">Fecha</label>
                                <div class="col-md-2">
                                    <input type="text" class="form-control input-sm" id="fecha" name="fecha" value="<?php echo date("d/m/Y"); ?>" readonly>
                                </div>
                                <label for="condiciones" class="col-md-1 control-label">Cond.</label>
                                <div class="col-md-3">
                                    <select class='form-control input-sm' id="condiciones" name="condicion">
                                        <option value="CONTADO">Contado</option>
                                        <option value="CREDITO">Credito</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="observacion" class="col-md-1 control-label">Observación</label>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-11">
                                    <input type="text" name="observacion" id="observacion" class="form-control input-sm" value="<?php echo $observacion ?>">
                                </div>
                            </div>	
                        </div>
                    </div>

                    <?php if ($imp_esp == "1") { ?>

                        <a data-toggle="collapse" data-target="#cond" class="btn btn-info"><span class="glyphicon glyphicon-chevron-down" ></span>Impuesto</a>
                        <br>
                        <div id="cond" class="collapse" class="panel panel-default">
                            <div class="panel panel-default">
                                <div class="panel-body">
                                    <div class="form-group row">
                                        <label for="impuesto1" class="col-md-2 control-label">IVA primario (<?php echo $impuesto1 ?>%)</label>
                                        <div class="col-md-1">
                                            <input type="radio" id="impuesto1" name="porc_impuesto" onclick="cambiar_impuesto(this.value)" value="<?php echo $impuesto1 ?>" checked>	
                                        </div>	
                                        <label for="imp_esp" class="col-md-2 control-label">IVA especial</label>
                                        <div class="col-md-1">
                                            <input type="radio" id="imp_esp" name="porc_impuesto" onclick="cambiar_impuesto('imp_esp')" value="imp_esp">
                                        </div>

                                    </div>

                                </div>
                            </div>					
                        </div>

                    <?php } ?>

                    <br><br>						
                    <div class="col-md-12">
                        <div class="pull-right">
                            <button type="button" class="btn btn-default btn-lg" data-toggle="modal" onclick="cotizacion();" data-target="#cargarCotizacion" <?php echo $disabled ?> data-toggle="tooltip" data-placement="top" title="Cargar cotización">
                                <span class="glyphicon glyphicon-folder-open"></span> 
                            </button>

                            <!--Campo oculto para guardar el id de la cotizacion-->
                            <input type="hidden" name="id_cotizacion" id="id_cotizacion">												
                            <!--<button type="button" class="btn btn-default" data-toggle="modal" data-target="#nuevoProducto" onclick="limpiar_modal();" <?php //echo $disabled  ?>>
                             <span class="glyphicon glyphicon-plus"></span> Nuevo producto
                            </button>-->

                            <button type="button" class="btn btn-default btn-lg" data-toggle="modal" data-target="#nuevoCliente" onclick="limpiar_modal();" <?php echo $disabled ?> data-toggle="tooltip" data-placement="top" title="Nuevo cliente">
                                <span class="glyphicon glyphicon-user"></span> 
                            </button>					
                            <button type="button" class="btn btn-default btn-lg" onclick="producto();" data-toggle="modal" data-target="#myModal" <?php echo $disabled ?> data-toggle="tooltip" data-placement="top" title="Buscar productos">
                                <span class="glyphicon glyphicon-search"></span> 
                            </button>
                            <button id="procesar" type="submit" class="btn btn-default btn-lg" data-toggle="tooltip" data-placement="top" title="Procesar" disabled="true" >
                                <span class="glyphicon glyphicon-print"></span> 
                            </button>
                        </div>	
                    </div>
            </form>	

            <div id="resultados" class='col-md-12' style="margin-top:10px"></div><!-- Carga los datos ajax -->			
        </div>
    </div>		
    <div class="row-fluid">
        <div class="col-md-12">

        </div>	
    </div>
</div>
<hr>

<?php
include("../templates/template_footer.php");
mysqli_close($con);
?>
<script type="text/javascript" src="js/nueva_factura.js"></script>
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>


</body>
</html>

<script type="text/javascript" src="js/maskedinput.js"></script>

<script>
                                jQuery(function ($) {
                                    $("#codigo").mask("a-99999999-9");
                                });
</script>