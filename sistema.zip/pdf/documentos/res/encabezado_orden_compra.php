
    <table cellspacing="0" style="width: 100%;">
        <tr>
            <td style="width: 40%; color: #444444;">
               <h2><span style="color: #34495e;font-size:25px;font-weight:bold">ORDEN DE COMPRA</span></h2>
  
            </td>
			<td style="width: 100%;text-align:center;">
             	<img style="width: 30%;" src="../../public/imagenes/<?php echo $fila['logo']; ?>" alt="Logo">
            </td><br>		
        </tr>
    </table>