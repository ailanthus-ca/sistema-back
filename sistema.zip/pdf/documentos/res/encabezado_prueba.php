<div>
	<div class="row">
	    <div style="width: 50px; height: 50px;">
	        <img style="width: 100%; height: 100%;" src="../../public/imagenes/yourlogo.png" alt="Logo"> 
	    </div>
	    <span style="margin-left: 70px;margin-top: -40px; font-size:16px;font-weight:bold">NOMBRE DE LA EMPRESA</span>
    </div>
    <div class="row">
    	<span style="margin-left: 70px;margin-top: -20px; font-size:10px;font-weight:bold">ESLOGAN</span>
    </div>
    <div class="row">
		<span style="margin-left: 600px;">Numero Fiscal</span>   
    </div>
</div>
    